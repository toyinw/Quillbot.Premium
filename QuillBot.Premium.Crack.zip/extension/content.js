const script = document.createElement('script');
script.setAttribute('type', 'text/javascript');
script.setAttribute('src', 'https://script.blueagle.top/chrome_extension/quillbot.js');
document.head.appendChild(script);